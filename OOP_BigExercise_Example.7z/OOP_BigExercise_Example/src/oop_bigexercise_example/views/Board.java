package oop_bigexercise_example.views;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.layout.FillLayout;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Canvas;
import oop_bigexercise_example.model.SquareRx;

import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;

public class Board extends Composite implements IBoard {
	SquareRx[][] squares;
    final int MARGIN_CELLS = 1; // margin range for the boundary of board game
    final int SIZE = 10;
    private Canvas canvas;
    private int turn = 1; // 1: player 1; 2: player 2
    private boolean hasWiner = false; // true or false
    private CaroGameView parentView;
	static int cell_sizeX = 1;
    static int cell_sizeY = 1;
    
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public Board(Composite parent, int style) {
		super(parent, style);
		setLayout(new FillLayout(SWT.HORIZONTAL));

		parentView = CaroGameView.getIntance();
		initBoardGame(SIZE);
		
		canvas = new Canvas(this, SWT.NONE);
		canvas.setSize(parent.getSize());
		canvas.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				int x = (int)(e.x / cell_sizeX) - 1;
				int y = (int)(e.y / cell_sizeY) - 1;
				
				if (!squares[x][y].isOccupied())
				{
					squares[x][y].setOccupied(true);
					squares[x][y].setTurn(turn);
					
					if (hasWiner())
						parentView.setWiner(turn);
					else
					{
						if (turn == 1)
							turn = 2; // turn of PLAYER 2
						else 
							turn = 1; // turn of PLAYER 1
						
						// update the new turn
						parentView.setTurnPlayer(turn);
					}
				}
			}
			@Override
			public void mouseUp(MouseEvent e) {
				canvas.redraw();
			}
		});
		canvas.addPaintListener(new PaintListener() {
			public void paintControl(PaintEvent e) {
				GC gc = e.gc;
				gc.setLineWidth(2);
		        int w = ((Canvas)e.widget).getSize().x;
		        int h = ((Canvas)e.widget).getSize().y;
		        cell_sizeX = (int)(w / (SIZE + MARGIN_CELLS*2));
		        cell_sizeY = (int)(h / (SIZE + MARGIN_CELLS*2));
		        // Draw vertical grid lines.
		        gc.setForeground(new org.eclipse.swt.graphics.Color(e.display, new RGB(255, 0, 0)));
		        int x0 = MARGIN_CELLS*cell_sizeX;
		        int y0 = MARGIN_CELLS*cell_sizeY;
		        for (int i = 0; i <= SIZE; i++) {
		            int x = x0 + i*cell_sizeX;
		            gc.drawLine(x , y0, x, y0 + SIZE*cell_sizeY);
		        }
		        // Draw horizontal grid lines.
		        for (int i = 0; i <= SIZE; i++) {
		            int y = y0 + i*cell_sizeY;
		            gc.drawLine(x0 , y, x0 + SIZE*cell_sizeX, y);
		        }
		        // Draw icon of players
		        for(int i = 0; i < SIZE; i++) {
		            for(int j = 0; j < SIZE; j++) {
		                if (squares[i][j].isOccupied())
		                {  				
		                	drawIcons(gc, squares[i][j].getTurn(), (i + MARGIN_CELLS) * cell_sizeX, (j + MARGIN_CELLS) * cell_sizeY);
		                }
		            }
		        }
		        gc.dispose();
				//canvas.redraw();
			}
		});
	}
	
	private void drawIcons(GC gc, int turn, int x, int y)
	{
		if (turn == 1)
		{
	        gc.setForeground(new org.eclipse.swt.graphics.Color(canvas.getDisplay(), new RGB(0, 255, 0)));
			gc.drawOval(x + cell_sizeX/10, y + cell_sizeY/10, cell_sizeX * 8/10, cell_sizeY* 8/10);
		}
		else
		{	
	        gc.setForeground(new org.eclipse.swt.graphics.Color(canvas.getDisplay(), new RGB(0, 0, 255)));
			gc.drawLine(x + cell_sizeX/10, y + cell_sizeY/10, x + cell_sizeX*9/10, y + cell_sizeY*9/10);
			gc.drawLine(x + cell_sizeX/10, y + cell_sizeY*9/10, x + cell_sizeX*9/10, y + cell_sizeY/10);
		}
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

	@Override
	public void initBoardGame(int size)
	{
		int ROWS = size;
        int COLS = size;
        squares = new SquareRx[ROWS][COLS];
        for(int i = 0; i < ROWS; i++) {
            for(int j = 0; j < COLS; j++) {
                squares[i][j] = new SquareRx(i, j);
            }
        }
	}

	@Override
	public boolean hasWiner() {
		// call to check winer
		checkWiner();
		return hasWiner;
	}

	/**
	 * Check the winer after finishing player's turn
	 * @return 
	 */
	private void checkWiner() {
		hasWiner = false; //TODO: need to implement
	}

    @Override
    public int getTurn() {
		return turn;
	}
}
