package oop_bigexercise_example.views;

public interface IBoard {
	boolean hasWiner();
	void initBoardGame(int size);
	int getTurn();
}
